<template>
    <div class="hero-img hero-img__design">
        <div class="container">
            <div class="text-block">
                <!-- <h1>THIS TEXT</h1>
                <p>SHOULD BE DYNAMIC</p> -->
            </div>
        </div>
    </div>
</template>

<script>
export default {
    name: 'HeroImage'
}
</script>

<style>

</style>
