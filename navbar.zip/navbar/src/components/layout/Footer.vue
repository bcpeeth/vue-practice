<template>
  <div class="footer bg-lightgrey">
    <div class="container py-5">
      <!-- <div class="row">
        <div class="col text-block">
          <h3>Disclaimer</h3>
          <p>Privacy Statement</p>
          <p>Conditions</p>
        </div>
        <div class="col text-block">
          <h3>Contact</h3>
          <p>Phone: 088-0775577</p>
          <p>Email: communicatie@fleximfoundation.com</p>
        </div>
        <div class="col text-block">
          <h3>Address</h3>
          <p>Wolwevershaven 30P</p>
          <p>3311AW Dordrecht</p>
          <p>Chamber of Commerce number: 72094443</p>
          <p>RSIN: 858983552</p>
        </div>
      </div> -->
    </div>
  </div>
</template>

<script>
export default {
  name: 'Footer' //this is the name of the component
}
</script>
<style>
    
</style>
