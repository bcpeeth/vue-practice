<template>
    <div class="header header-image">
        <div class="container">
        </div>
    </div>


</template>

<script>
export default {
    name: 'Header'
}
</script>

<style>

</style>