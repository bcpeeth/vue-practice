<template>
  <div>
    <HeroImage/>
<!-- intro-text -->
    <div class="container-fluid py-5">
      <div class="row justify-content-center">
        <div class="col-md-6 text-center text-block">
          <h1>Projecten</h1>
          <p>De Flexim Foundation zet zich continu in voor diverse projecten. Hieronder vindt u een overzicht van lopende én afgeronde projecten waar de Foundation zich hard voor maakt. Voelt u zich ook betrokken bij een project en wilt u hier meer over weten, neem dan contact met ons op!</p>
        </div>
      </div>
    </div>

        <div class="container-fluid py-5">
      <div class="row justify-content-center">
        <div class="col-md-6 text-center text-block">
          <h1>Projecten</h1>
          <p>De Flexim Foundation zet zich continu in voor diverse projecten. Hieronder vindt u een overzicht van lopende én afgeronde projecten waar de Foundation zich hard voor maakt. Voelt u zich ook betrokken bij een project en wilt u hier meer over weten, neem dan contact met ons op!</p>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
// import carousel from 'vue-owl-carousel'
import HeroImage from './HeroImage'
export default {
  name: 'About', //this is the name of the component
  components: {
    'HeroImage': HeroImage,
     },
}
</script>
<style>

</style>
